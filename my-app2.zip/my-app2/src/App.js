import React, { useState } from "react";
import ReactDOM from "react-dom";
import "bootstrap/dist/css/bootstrap.css";
import logo from './logo.svg';
import './App.css';
import {
  ListGroup,
  ListGroupItem,
  Button,
  Form,
  Input,
  InputGroup
} from "reactstrap";

const initialTodoList = [
  "Teach Intro to React Hooks",
  "Get coffee",
  "Fix all the bugs"
];

function App() {
  const {
    todo,
    todoList,
    handleInputChange,
    handleSubmit,
    handleRemoveClick
  } = useTodoState();

  return (
    <section>
      <h1>TODO</h1>
      <ListGroup>
        {todoList.map((item, i) => {
          return (
            <ListGroupItem key={i}>
              {item}
              <Button close onClick={() => handleRemoveClick(i)} />
            </ListGroupItem>
          );
        })}
      </ListGroup>
      <Form onSubmit={handleSubmit}>
        <InputGroup>
          <Input value={todo} onChange={handleInputChange} />
          <Button>Add</Button>
        </InputGroup>
      </Form>
    </section>
  );
}

function useTodoState() {
  const [todo, setTodo] = useState("");
  const [todoList, setTodoList] = useState(initialTodoList);
  
  fetch(http://www.example.com/api/json/x/a/search.php?s=category)
  .then(response => response.json())
  .then((jsonData) => {
    // jsonData is parsed json object received from url
    console.log(jsonData)
  })
  
  
  .catch((error) => {
    // handle your errors here
    console.error(error)
  })
  function handleInputChange(e) {
    setTodo(e.target.value);
  }

  function handleSubmit(e) {
    e.preventDefault();
    setTodoList([...todoList, todo]);
    setTodo("");
  }

  function handleRemoveClick(todoIndex) {
    const newTodoList = todoList.filter((_, i) => i !== todoIndex);
    setTodoList(newTodoList);
  }

  return {
    todo,
    todoList,
    handleInputChange,
    handleSubmit,
    handleRemoveClick
  };
}

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);

function App22() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
}

export default App;
